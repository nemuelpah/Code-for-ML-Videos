https://huggingface.co/hustvl/yolos-tiny

